#include "ShaderIncludes.hlsli"
// Define a constant buffer
// - Each buffer needs an identifier
// ExternalData is used to signify to the programmer the intent of this cbuffer
//           | 
//			 |  register tells the shader which slot we're referring to when accessing the var in cbuffer
//           |           |
//           V           V  all constant buffers are bound to b registers, 0 is an index (not  arbitrary) 
cbuffer ExternalData : register(b0)
{

	matrix world;
	matrix worldInvTranspose;
	matrix view;
	matrix proj;
}


// --------------------------------------------------------
// The entry point (main method) for our vertex shader
// 
// - Input is exactly one vertex worth of data (defined by a struct)
// - Output is a single struct of data to pass down the pipeline
// - Named "main" because that's the default the shader compiler looks for
// --------------------------------------------------------
VertexToPixel main( VertexShaderInput input )
{
	// Set up output struct
	VertexToPixel output;

	// Here we're essentially passing the input position directly through to the next
	// stage (rasterizer), though it needs to be a 4-component vector now.  
	// - To be considered within the bounds of the screen, the X and Y components 
	//   must be between -1 and 1.  
	// - The Z component must be between 0 and 1.  
	// - Each of these components is then automatically divided by the W component, 
	//   which we're leaving at 1.0 for now (this is more useful when dealing with 
	//   a perspective projection matrix, which we'll get to in the future).
	//output.screenPosition = float4(input.localPosition, 1.0f);
	//output.screenPosition = float4(input.localPosition + offset, 1.0f);
	//output.screenPosition = mul(world, float4(input.localPosition, 1.0f));

	// Mutiply the three matrices together first
	matrix wvp = mul(proj, mul(view, world));
	output.screenPosition = mul(wvp, float4(input.localPosition, 1.0f));
	
	output.uv = input.uv;

	output.normal = mul((float3x3)worldInvTranspose, input.normal);
	output.worldPosition = mul(world, float4(input.localPosition, 1)).xyz;


	// Whatever we return will make its way through the pipeline to the
	// next programmable stage we're using (the pixel shader for now)
	return output;
}